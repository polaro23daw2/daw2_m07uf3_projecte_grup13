<?php

namespace App\Http;

use Illuminate\Foundation\Http\Kernel as HttpKernel;

class Kernel extends HttpKernel
{
    protected $middleware = [
        // Middleware global que se ejecuta en todas las solicitudes
        \App\Http\Middleware\AdminAuth::class,
        // Otros middlewares globales...
    ];

    protected $middlewareGroups = [
        'web' => [
            // Middleware específicos del grupo web
        ],

        'api' => [
            // Middleware específicos del grupo api
        ],
    ];

    protected $routeMiddleware = [
        // Registro de middlewares individuales que puedes aplicar a rutas
        'adminAuth' => \App\Http\Middleware\AdminAuth::class, // Aquí añades tu middleware personalizado
        // Otros middlewares...
    ];
}
